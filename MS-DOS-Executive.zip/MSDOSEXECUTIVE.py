import turtle

# Setup
screen = turtle.Screen()
screen.setup(800, 600)
screen.title("MS-DOS Executive")
screen.bgcolor("black")

pen = turtle.Turtle()
pen.hideturtle()
pen.speed(0)

# Data
menus = ["File", "View", "Special"]
selected_menu = 0

files = [
    "AUTOEXEC.BAT", "COMMAND.COM", "NOTEPAD.EXE",
    "CALC.EXE", "WRITE.EXE", "PAINT.EXE"
]
selected_file = 0

mode = "files"
open_window = None

# Draw rectangle
def draw_rect(x, y, w, h, color):
    pen.penup()
    pen.goto(x, y)
    pen.setheading(0)
    pen.color(color)
    pen.begin_fill()
    for _ in range(2):
        pen.forward(w)
        pen.right(90)
        pen.forward(h)
        pen.right(90)
    pen.end_fill()

# Draw popup window
def draw_window(title, content):
    draw_rect(-200, 100, 400, 250, "lightgray")
    draw_rect(-200, 100, 400, 30, "blue")

    pen.goto(-180, 80)
    pen.color("white")
    pen.write(title, font=("Courier", 12, "bold"))

    pen.goto(-180, 40)
    pen.color("black")
    pen.write(content, font=("Courier", 12, "normal"))

def draw_ui():
    pen.clear()

    # Title bar
    draw_rect(-400, 300, 800, 30, "blue")
    pen.goto(-120, 280)
    pen.color("white")
    pen.write("MS-DOS Executive", font=("Courier", 12, "bold"))

    # Menu bar
    draw_rect(-400, 270, 800, 30, "lightgray")

    x = -380
    for i, m in enumerate(menus):
        text_width = len(m) * 9

        # Highlight FIRST (fixed position)
        if mode == "menu" and i == selected_menu:
            draw_rect(x - 4, 268, text_width + 8, 24, "blue")
            pen.color("white")
        else:
            pen.color("black")

        pen.goto(x, 250)
        pen.write(m, font=("Courier", 12, "normal"))

        x += text_width + 30

    # Main area
    draw_rect(-400, 240, 800, 440, "white")

    # File list
    y = 200
    
    for i, file in enumerate(files):

        if mode == "files" and i == selected_file:
            # tuned to match Turtle's text rendering
            draw_rect(-395, y + 18, 320, 22, "blue")
            pen.color("white")
        else:
            pen.color("black")

        pen.goto(-380, y)
        pen.write(file, font=("Courier", 12, "normal"))

        y -= 25

    # Draw window if open
    if open_window:
        draw_window(open_window["title"], open_window["content"])

# Controls
def move_up():
    global selected_file
    if mode == "files" and selected_file > 0:
        selected_file -= 1
    draw_ui()

def move_down():
    global selected_file
    if mode == "files" and selected_file < len(files) - 1:
        selected_file += 1
    draw_ui()

def move_left():
    global selected_menu
    if mode == "menu" and selected_menu > 0:
        selected_menu -= 1
    draw_ui()

def move_right():
    global selected_menu
    if mode == "menu" and selected_menu < len(menus) - 1:
        selected_menu += 1
    draw_ui()

def switch_mode():
    global mode
    mode = "menu" if mode == "files" else "files"
    draw_ui()

def select_item():
    global open_window

    if mode == "files":
        file = files[selected_file]

        if file == "NOTEPAD.EXE":
            open_window = {"title": "Notepad", "content": "Hello from Notepad!"}
        elif file == "CALC.EXE":
            open_window = {"title": "Calculator", "content": "2 + 2 = 4"}
        else:
            open_window = {"title": file, "content": "Program opened."}

    else:
        open_window = {"title": menus[selected_menu], "content": "Menu opened"}

    draw_ui()

def close_window():
    global open_window
    open_window = None
    draw_ui()

# Key bindings
screen.listen()
screen.onkey(move_up, "Up")
screen.onkey(move_down, "Down")
screen.onkey(move_left, "Left")
screen.onkey(move_right, "Right")
screen.onkey(select_item, "Return")
screen.onkey(switch_mode, "Tab")
screen.onkey(close_window, "Escape")

# Start
draw_ui()
turtle.done()
